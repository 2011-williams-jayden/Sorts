//Merge Class Implementation
//Date: 10/24/21
//Author: Jayden Williams
#include "merge.h"

using namespace std;

void merge(int data[], int left, int mid, int right, size_t &comp, size_t &swaps)
{
    int i,j,k;
    int num1 = mid - left + 1;
    int num2 = right - mid;

    int Left[num1], Right[num2];

    comp = 0;
    swaps = 0;

    for (i = 0; i < num1; i++)
    {
        Left[i] = data[left + i];
    }
    for (j = 0; j < num2; j++)
    {
        Right[j] = data[mid + 1 + j];
    }

    i = 0;
    j = 0;
    k = left;

    while (i < num1 && j < num2)
    {
        comp++;
        if (Left[i] <= Right[j])
        {
            data[k] = Left[i];
            i++;
        }
        else
        {
            data[k] = Right[j];
            j++;
        }
        k++;
    }

    while (i < num1)
    {
        swaps++;
        data[k] = Left[i];
        i++;
        k++;
    } 
    
    while (j < num2)
    {
        data[k] = Right[j];
        j++;
        k++;
    }
}

void mergeSort(int data[], int right, int left, size_t &comp, size_t &swaps)
{
    if (left >= right)
    {
        return;
    }
    
    auto mid = left + (right - left)/2;

	mergeSort(data, left, mid, comp, swaps);
    mergeSort(data, mid + 1, right, comp, swaps);
	merge(data, left, mid, right, comp, swaps);
}