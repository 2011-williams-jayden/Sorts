//Selection Class Definition
//Date: 10/24/21
//Author: Jayden Williams
#ifndef SELECTION_H
#define SELECTION_H

#include <utility>

using namespace std;

void selectSort(int data[], int i, int size, size_t &comp, size_t &swaps);
#endif