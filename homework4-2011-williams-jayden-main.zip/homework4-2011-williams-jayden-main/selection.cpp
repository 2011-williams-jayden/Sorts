//Selection Class Implementation
//Date: 10/24/21
//Author: Jayden Williams
#include "selection.h"

using namespace std;

void selectSort(int data[], int i, int size, size_t &comp, size_t &swaps)
{
    comp = 0;
    swaps = 0;

    for (int i = 0; i < size; i++)
    {
        swaps++;
        int smallIndex = i;
        for (int j = i + 1; j < size; j++)
        {
            comp++;
            if (data[j] < data[smallIndex])
            {
                smallIndex = j;
            }
            int temp = data[i];
            data[i] = data[smallIndex];
            data[smallIndex] = temp;
        }
        
    }
    
}