//Merge Class Definition
//Date: 10/24/21
//Author: Jayden Williams
#ifndef MERGE_H
#define MERGE_H

#include <utility>

using namespace std;

void merge(int data[], int left, int mid, int right, size_t &comp, size_t &swaps);
void mergeSort(int data[], int right, int left, size_t &comp, size_t &swaps);

#endif