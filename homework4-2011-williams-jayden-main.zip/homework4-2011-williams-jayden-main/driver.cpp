//Main Driver
//Date: 10/22/21
//Author: Jayden Williams
#include <fstream>
#include <iostream>
#include <chrono>
#include "selection.h"
#include "bubble.h"
#include "merge.h"
using namespace std;
using namespace std::chrono;

int getmenuType();
size_t getdataSize();
void generateArray(int data[], size_t size); 
void calcAVG(string file, size_t totalRuns, size_t totalSwap, size_t totalComp);


int main()
{
    int i, p, menuChoice, right, left, mid;
    size_t swaps, comp, totalRuns, totalSwap, totalComp, avgRuns, avgSwaps, avgComps, size, runTime;
    comp = 0;
    swaps = 0;
    runTime = 0;

	do{ 
        fstream file;
        menuChoice = getmenuType(); 
		switch(menuChoice)
        {

			case 1:
            {
                size = getdataSize();
                int data[size];
                string name = "bubble.csv";
                //file.app(char(size), size | ios::app);
                file.open(name, ios::out | ios::app);
                file << size << "\n";
                file << ",Unsorted,," << "\n";
                for (int ind = 0; ind < 10; ind++)
                {
                    comp = 0;
                    swaps = 0;
                    runTime = 0;
                    generateArray(data,size);
                    auto start = high_resolution_clock::now();
                    bubbleSort(data, size, comp, swaps);
                    auto stop = high_resolution_clock::now();
                    auto run = duration_cast<microseconds>(stop - start);
                    runTime = runTime + run.count();
                    file << "," << runTime << "," << comp << "," << swaps << "\n";
                    totalRuns += run.count();
                    totalSwap += swaps;
                    totalComp += comp;

                }
                calcAVG("bubble.csv", totalRuns, totalSwap, totalComp);
                           
                file << ",Sorted,," << "\n";
                totalRuns = 0;
                totalSwap = 0;
                totalComp = 0;

                for (int ind = 0; ind < 10; ind++)
                {
                    comp = 0;
                    swaps = 0;
                    runTime = 0;
                    auto start = high_resolution_clock::now();
                    bubbleSort(data, size, comp, swaps);
                    auto stop = high_resolution_clock::now();
                    auto run = duration_cast<microseconds>(stop - start);
                    runTime = runTime + run.count();
                    file << "," << runTime << "," << comp << "," << swaps << "\n";
                    totalRuns += run.count();
                    totalSwap += swaps;
                    totalComp += comp;
                }
                calcAVG("bubble.csv", totalRuns, totalSwap, totalComp);
                file.close();
				break;
            }
			case 2:
            {
                size = getdataSize();
                int data[size];
                string name= "selection.csv";
                file.open(name, ios::out | ios::app);
                file << size << endl;                
                for (int ind = 0; ind < 10; ind++)
                {
                    comp = 0;
                    swaps = 0;
                    runTime = 0;
                    generateArray(data, size);
                    auto start = high_resolution_clock::now();
                    selectSort(data, i, size, comp, swaps);
                    auto stop = high_resolution_clock::now();
                    auto run = duration_cast<microseconds>(stop - start);
                    runTime = runTime + run.count();
                    file << "," << runTime << "," << comp << "," << swaps << "\n";
                    totalRuns += run.count();
                    totalSwap += swaps;
                    totalComp += comp;
                }
                calcAVG("selection.csv", totalRuns, totalSwap, totalComp);
                        
                file << ",Sorted,," << "\n";
                totalRuns = 0;
                totalSwap = 0;
                totalComp = 0;

                for (int ind = 0; ind < 10; ind++)
                {
                    comp = 0;
                    swaps = 0;
                    runTime = 0;
                    auto start = high_resolution_clock::now();
                    selectSort(data, i, size, comp, swaps);
                    auto stop = high_resolution_clock::now();
                    auto run = duration_cast<microseconds>(stop - start);
                    runTime = runTime + run.count();
                    file << "," << runTime << "," << comp << "," << swaps << "\n";
                    totalRuns += run.count();
                    totalSwap += swaps;
                    totalComp += comp;
                }
                calcAVG("selection.csv", totalRuns, totalSwap, totalComp);
             
                file << ",Unsorted,," << "\n";
                file.close();
				break;
            }
			case 3:
            {
                size = getdataSize();
                int data[size];
                string name= "merge.csv";
                file.open(name, ios::out | ios::app);
                file << size << endl;                
                for (int ind = 0; ind < 10; ind++)
                {
                    comp = 0;
                    swaps = 0;
                    runTime = 0;
                    generateArray(data,size);
                    auto start = high_resolution_clock::now();
                    mergeSort(data, size, 0, comp, swaps);
                    auto stop = high_resolution_clock::now();
                    auto run = duration_cast<microseconds>(stop - start);
                    runTime = runTime + run.count();
                    file << "," << runTime << "," << comp << "," << swaps << "\n";
                    totalRuns += run.count();
                    totalSwap += swaps;
                    totalComp += comp;
                }
                calcAVG("merge.csv", totalRuns, totalSwap, totalComp);
             
                file << ",Sorted,," << "\n";
                totalRuns = 0;
                totalSwap = 0;
                totalComp = 0;

                for (int ind = 0; ind < 10; ind++)
                {
                    comp = 0;
                    swaps = 0;
                    runTime = 0;
                    auto start = high_resolution_clock::now();
                    mergeSort(data, size, 0, comp, swaps);
                    auto stop = high_resolution_clock::now();
                    auto run = duration_cast<microseconds>(stop - start);
                    runTime = runTime + run.count();
                    file << "," << runTime << "," << comp << "," << swaps << "\n";
                    totalRuns += run.count();
                    totalSwap += swaps;
                    totalComp += comp;
                }
                calcAVG("merge.csv", totalRuns, totalSwap, totalComp);
             
                file << ",Unsorted,," << "\n";              
                file.close();
				break;
            }
			case 0:
            {
				break;
            }
			default:
            {
				cout << "Please enter a valid option" << endl;
				break;
            }
		}
	}
    while (menuChoice != 0);
    {
        return 0;
    }
}

int getmenuType()
{
	int menuchoice;

	cout << "Welcome to Sorts!" << endl;
	cout << "Which Sort Would You Like To Do?" << endl;
	cout << "1. Bubble Sort" << endl;
	cout << "2. Selection Sort" << endl;
	cout << "3. Merge Sort" << endl;
	cout << "0. Exit" << endl;

	cin >> menuchoice;
	return menuchoice;
}

size_t getdataSize()
{
	size_t size;

	cout << "What Size?" << endl;
	cin >> size;
	return size;
}

void generateArray(int data[], size_t size)
{

    for (int i = 0; i < size-1; i++)
    {
        data[i] = (rand() % 1000000) + 1;
    }
    
}

void calcAVG(string file, size_t totalRuns, size_t totalSwap, size_t totalComp)
{
    fstream file2;
    size_t avgRuns, avgSwaps, avgComps;
    avgRuns = totalRuns/10;
    avgSwaps = totalSwap/10;
    avgComps = totalComp/10;

    file2.open(file, ios::out | ios::app);
    file2 << "AVG: " << avgRuns << "," << avgComps << "," << avgSwaps  << "\n";
}