//Bubble Class Definition
//Date: 10/24/21
//Author: Jayden Williams
#ifndef BUBBLE_H
#define BUBBLE_H

#include <utility>
#include <iostream>

using namespace std;

void bubbleSort(int data[], int size, size_t &comp, size_t &swaps);

#endif
