//Bubble Class Definition
//Date: 10/24/21
//Author: Jayden Williams
#include "bubble.h"
#include <iostream>

using namespace std;

void bubbleSort(int data[], int size, size_t &comp, size_t &swaps)
{
    comp = 0;
    swaps = 0;

    for (int i = 0; i < size-2; i++)
    {
        for (int j = 0; j < size-2; j++)
        {
            comp++;
            if (data[j] > data[j+1])
            {
                swap(data[j+1], data[j]);
                swaps++;
            }
            
        }
        
    }
    
}
